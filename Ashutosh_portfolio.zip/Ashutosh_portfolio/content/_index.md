---
title: "Data Science Portfolio"
featured_image: '/images/dennis-kummer-52gEprMkp7M-unsplash.jpg'
description: "Hi! My name is Ashutosh Bele."
---
Welcome to my Data Science Portfolio.I have a passion for working for data-driven, innovative companies.
