---
title: "About"
description: "Hi! My name is Ashutosh Bele. I'm a Aspiring Data Scientist."
featured_image: '/images/jeremy-thomas-rMmibFe4czY-unsplash.jpg'
---
{{< figure src="/images/profile.jpg"  >}}

Data Science is my passion. My name is Ashutosh Bele and I have been learning data science field doing various courses and specializations for the last 1 year. I have completed my bachlors degree in the field of Information Technology. 
