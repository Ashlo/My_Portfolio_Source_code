---

description: "A ball classifier to identify balls from different sports."
featured_image: "/images/diabetes.png"
title: "Project 2: Diabetes Prediction (Flask App)"
---

For this example project I built a Diabetes Prediction App to identify whether a person has diabetes or not. This could be useful for someone who is diabetic. They could take thier report of diabetes and an enter into textfields and then the App could serve them the result. This is the underlying model for building something with those capabilities.

I was able to get the model to predict the diabetes of the patient with 84% accuracy after minimal tuning. For most of the cases this would meet the need of an end user of the app. To get these results I used Logistic Regression on a dataset. This created time efficiencies and solid results.

{{< figure src="/images/diabetes.png" >}}

[Link to GitHub Repository](https://github.com/Ashlo/diabetes--prediction--Flask)
