---
description: "A tool that estimates data science salaries."
featured_image: "/images/Corona-Covid19.png"
title: "Project 1: Covid 19 X ray Prediction Flask application"
---

* I built a Covid19 Prediction App to identify whether a person has covid19 or not.They could take thier image of x ray and serve to the web app to get the result.
* I was able to get the model to predict the Covid with fine accuracy. For most of the cases this would meet the need of an end user of the app.
* Collected several images of xray from various sources and built an model over it.
* Built a client facing API using flask

{{< figure src="/images/Corona-Covid19.png" >}}

[Link to GitHub Repository](https://github.com/Ashlo/Covid19-xray-Flask-app)
